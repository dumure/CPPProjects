#pragma once
#include "MoneyGuard.h"
class Registration
{
public:
	void sign_up();
};

