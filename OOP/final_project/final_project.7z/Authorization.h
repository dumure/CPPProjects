#pragma once
#include "Registration.h"
class Authorization
{
public:
	void sign_in();
};

