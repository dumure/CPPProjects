#pragma once
#include "SHA2.h"
class StringEncryptor
{
public:
	std::string encrypt(const std::string& a_string);
};

