#include "Category.h"

Category::Category(const std::string& a_category_name) : m_category_name(a_category_name) { }

Category::Category() { }
