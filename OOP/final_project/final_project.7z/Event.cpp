#include "Event.h"

Event::~Event() {}

