#include "GreaterEquals.h"

bool GreaterEquals::operator()(int a, int b)
{
	return a >= b;
}