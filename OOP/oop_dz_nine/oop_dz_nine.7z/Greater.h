#pragma once
class Greater
{
public:
	bool operator() (int a, int b);
};
