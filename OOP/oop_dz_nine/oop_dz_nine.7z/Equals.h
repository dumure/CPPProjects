#pragma once
class Equals
{
public:
	bool operator()(int a, int b);
};

