#include "Equals.h"

bool Equals::operator()(int a, int b)
{
	return a == b;
}