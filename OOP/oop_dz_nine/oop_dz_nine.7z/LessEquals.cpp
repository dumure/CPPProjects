#include "LessEquals.h"

bool LessEquals::operator()(int a, int b)
{
	return a <= b;
}