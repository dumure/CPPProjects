#pragma once
class GreaterEquals
{
public:
	bool operator()(int a, int b);
};

