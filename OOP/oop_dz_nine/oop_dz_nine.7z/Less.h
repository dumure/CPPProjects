#pragma once
class Less
{
public:
	bool operator() (int a, int b);
};

