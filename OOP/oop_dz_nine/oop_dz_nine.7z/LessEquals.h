#pragma once
class LessEquals
{
public:
	bool operator()(int a, int b);
};

