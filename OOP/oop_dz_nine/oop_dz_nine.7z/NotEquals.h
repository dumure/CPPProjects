#pragma once
class NotEquals
{
public:
	bool operator()(int a, int b);
};

