#include "Greater.h"

bool Greater::operator() (int a, int b)
{
	return a > b;
}
