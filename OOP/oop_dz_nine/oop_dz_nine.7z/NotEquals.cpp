#include "NotEquals.h"

bool NotEquals::operator()(int a, int b)
{
	return a != b;
}