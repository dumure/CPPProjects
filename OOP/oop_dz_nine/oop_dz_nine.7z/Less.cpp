#include "Less.h"

bool Less::operator() (int a, int b)
{
	return a < b;
}

